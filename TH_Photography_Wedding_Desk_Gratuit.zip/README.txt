TH PHOTOGRAPHY — WEDDING DESK (version gratuite)

Mise en ligne :
1. Ouvrez votre dépôt GitHub.
2. Remplacez le fichier index.html à la racine par celui de cette archive.
3. Dans Settings > Pages, choisissez Deploy from a branch, branche main, dossier /(root), puis Save.
4. Attendez le déploiement GitHub Pages.

Fonctions : clients et dates de mariage, statut de livraison, forfaits/acompte/solde en FCFA, tâches, export et restauration JSON.

Attention : les données sont enregistrées localement dans le navigateur de l'appareil. Il n'y a pas de serveur ni de synchronisation entre appareils. Faites des sauvegardes régulières.